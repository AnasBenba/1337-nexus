from uuid import UUID, uuid4

from sqlalchemy import CheckConstraint, ColumnElement, String, or_, select, text
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Mapped, mapped_column

from app.shared.models import Base


class Users(Base):
    __tablename__ = "users"
    # Same values as app.oauth.permissions.Role; the DB rejects anything else.
    __table_args__ = (
        CheckConstraint("role IN ('user', 'admin', 'superadmin')", name="ck_users_role"),
    )

    id: Mapped[UUID] = mapped_column(
        primary_key=True,
        default=uuid4,
        server_default=text("gen_random_uuid()"),
    )
    login: Mapped[str] = mapped_column()
    fullname: Mapped[str] = mapped_column()
    role: Mapped[str] = mapped_column(default="user")  # see app.oauth.permissions.Role
    intra_id: Mapped[int | None] = mapped_column(nullable=True)  # set for 42 accounts
    # Email/password accounts. Emails are stored lowercase; password_hash is Argon2 (salted),
    # never the password itself. 42-only accounts have no password_hash.
    email: Mapped[str | None] = mapped_column(String(254), unique=True, nullable=True)
    password_hash: Mapped[str | None] = mapped_column(String(255), nullable=True)
    bio: Mapped[str | None] = mapped_column(String(500), nullable=True)
    avatar_url: Mapped[str | None] = mapped_column(String(255), nullable=True)


def login_or_name_contains(q: str) -> ColumnElement[bool]:
    """Case-insensitive "login or fullname contains q" filter, used by user search."""
    # Escape LIKE wildcards so "%" or "_" in the query are matched literally.
    pattern = "%" + q.strip().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
    return or_(Users.login.ilike(pattern, escape="\\"), Users.fullname.ilike(pattern, escape="\\"))


async def get_user_by_intra_id(db: AsyncSession, intra_id: int) -> Users | None:
    result = await db.execute(select(Users).where(Users.intra_id == intra_id))
    return result.scalar_one_or_none()
