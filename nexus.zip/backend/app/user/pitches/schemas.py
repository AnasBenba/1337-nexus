from datetime import datetime
from enum import Enum
from uuid import UUID

from pydantic import BaseModel, ConfigDict, computed_field


class VoteDirection(str, Enum):
    UP = "up"
    DOWN = "down"


class PitchVoteRequest(BaseModel):
    direction: VoteDirection


class PitchVoteResponse(BaseModel):
    pitch_id: UUID
    upvotes: int
    downvotes: int
    my_vote: VoteDirection | None


class PitchStatus(str, Enum):
    DRAFT = "draft"
    PUBLISHED = "published"
    ARCHIVED = "archived"
    PENDING = "pending"


class PitchCategory(str, Enum):
    TECH = "Technology"
    HEALTH = "Health"
    BUSINESS = "Business"
    EDUCATION = "Education"
    ENVIRONMENT = "Environment"
    ENTERTAINMENT = "Entertainment"
    SOCIAL_IMPACT = "Social Impact"
    FINANCE = "Finance"
    FOOD_BEVERAGE = "Food & Beverage"
    FASHION_DESIGN = "Fashion & Design"


class PitchCreate(BaseModel):
    title: str
    content: str
    category: PitchCategory
    description: str | None = None
    status: PitchStatus = PitchStatus.DRAFT


class PitchResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: UUID
    title: str
    content: str
    rendered_content: str | None = None
    category: PitchCategory
    status: PitchStatus
    description: str | None = None
    author_id: UUID | None = None
    created_at: datetime | None = None

    @computed_field  # type: ignore[prop-decorator]
    @property
    def state(self) -> PitchStatus:
        return self.status
