import {
  ApplySuggestionResponse,
  DismissSuggestionResponse,
  RefineResponse,
  RefineStatusResponse,
} from './types';

export class ApiError extends Error {
  status: number;
  detail: string;
  isConflict: boolean;
  isStale: boolean;
  isRateLimit: boolean;
  retryAfter?: number;

  constructor(status: number, detail: string, retryAfter?: number) {
    super(detail);
    this.name = 'ApiError';
    this.status = status;
    this.detail = detail;
    this.isConflict = status === 409;
    this.isStale =
      status === 409 &&
      (detail.toLowerCase().includes('version token') ||
        detail.toLowerCase().includes('stale'));
    this.isRateLimit = status === 429;
    this.retryAfter = retryAfter;
  }
}

function getHeaders(userId?: string | number): HeadersInit {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  if (userId !== undefined) {
    headers['X-User-Id'] = String(userId);
  }
  return headers;
}

export async function requestRefine(
  pitchId: string,
  userId?: string | number
): Promise<RefineResponse> {
  const res = await fetch(`/api/user/projects/refine-project/${pitchId}/refine`, {
    method: 'POST',
    credentials: 'include',
    headers: getHeaders(userId),
    body: JSON.stringify({}),
  });

  if (!res.ok) {
    const errorBody = await res.json().catch(() => ({ detail: res.statusText }));
    const retryAfterHeader = res.headers.get('Retry-After');
    const retryAfter = retryAfterHeader ? parseInt(retryAfterHeader, 10) : undefined;
    throw new ApiError(
      res.status,
      errorBody.detail || 'Failed to submit refine request',
      retryAfter
    );
  }

  return res.json();
}

export async function getRefineStatus(
  pitchId: string,
  userId?: string | number
): Promise<RefineStatusResponse> {
  const res = await fetch(`/api/user/projects/refine-project/${pitchId}/status`, {
    method: 'GET',
    credentials: 'include',
    headers: getHeaders(userId),
  });

  if (!res.ok) {
    const errorBody = await res.json().catch(() => ({ detail: res.statusText }));
    throw new ApiError(res.status, errorBody.detail || 'Failed to retrieve critique status');
  }

  return res.json();
}

export async function applySuggestion(
  pitchId: string,
  suggestionId: string,
  versionToken: string,
  userId?: string | number
): Promise<ApplySuggestionResponse> {
  const res = await fetch(
    `/api/user/projects/refine-project/${pitchId}/suggestions/${suggestionId}/apply`,
    {
      method: 'POST',
      credentials: 'include',
      headers: getHeaders(userId),
      body: JSON.stringify({ version_token: versionToken }),
    }
  );

  if (!res.ok) {
    const errorBody = await res.json().catch(() => ({ detail: res.statusText }));
    throw new ApiError(res.status, errorBody.detail || 'Failed to apply suggestion');
  }

  return res.json();
}

export async function dismissSuggestion(
  pitchId: string,
  suggestionId: string,
  userId?: string | number
): Promise<DismissSuggestionResponse> {
  const res = await fetch(
    `/api/user/projects/refine-project/${pitchId}/suggestions/${suggestionId}/dismiss`,
    {
      method: 'POST',
      credentials: 'include',
      headers: getHeaders(userId),
    }
  );

  if (!res.ok) {
    const errorBody = await res.json().catch(() => ({ detail: res.statusText }));
    throw new ApiError(res.status, errorBody.detail || 'Failed to dismiss suggestion');
  }

  return res.json();
}
